import React from 'react'
import { TwitterIcon } from '../../assets/images/Icons'
import { Link } from 'react-router-dom'
import Input from '../../components/Input'
import Button from '../../components/Button'

function Signin() {
  return (
  <form autoComplete='off' className='w-[450px] mx-auto mt-[60px]'>
    <Link className='mb-[36px] inline-block' to={'/'}><TwitterIcon/></Link>
    <h1 className='text-[42px] font-black mb-[36px]'>Log in to Twitter</h1>
    <Input placeholder={'Phone number, email addr'} type={'text'} name={'login'} extraClass={'mb-[25px]'} />
    <Input placeholder={'Password'} type={'password'} name={'password'}  extraClass={'mb-[25px]'}/>
    <Button title={'Login'} type={'submit'}/>
  </form>
  )
}

export default Signin
