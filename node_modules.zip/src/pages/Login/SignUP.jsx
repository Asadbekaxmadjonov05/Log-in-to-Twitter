import React from 'react'

function SignUP() {
  return (
   <h1>sign-up</h1>
  )
}

export default SignUP
